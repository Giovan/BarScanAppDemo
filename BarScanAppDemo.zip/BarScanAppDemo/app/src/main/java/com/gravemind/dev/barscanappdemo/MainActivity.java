package com.gravemind.dev.barscanappdemo;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbAccessory;
import android.hardware.usb.UsbManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String ACTION_USB_PERMISSION =
            "com.android.example.USB_PERMISSION";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        UsbManager manager = (UsbManager) getSystemService(Context.USB_SERVICE);
        final UsbAccessory[] accessoryList = manager.getAccessoryList();
        final UsbAccessory accessory = (accessoryList == null ? null : accessoryList[0]);
        if (accessory != null) {
            Log.d("accessory", accessory.getModel());
            Toast.makeText(this, accessory.getModel(), Toast.LENGTH_LONG).show();
        }

        /* manager.requestPermission(accessory, permissionIntent);

        permissionIntent = PendingIntent.getBroadcast(this, 0, new Intent(ACTION_USB_PERMISSION), 0);
        IntentFilter filter = new IntentFilter(ACTION_USB_PERMISSION);
        registerReceiver(usbReceiver, filter); */

        // Intent intent = new Intent(this, MyBroadCastReceiver.class);
        // PendingIntent pendingIntent = PendingIntent.getBroadcast(this.getApplicationContext(), 12345678, intent, 0);

        /* AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis()
                + (1000), pendingIntent); */
        // Toast.makeText(this,"USB READER", Toast.LENGTH_LONG).show();
    }

    /* private final BroadcastReceiver usbReceiver = new BroadcastReceiver() {

        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (ACTION_USB_PERMISSION.equals(action)) {
                synchronized (this) {
                    UsbDevice device = (UsbDevice)intent.getParcelableExtra(UsbManager.EXTRA_DEVICE);

                    if (intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)) {
                        if(device != null){
                            //call method to set up device communication
                        }
                    }
                    else {
                        Log.d(TAG, "permission denied for device " + device);
                    }
                }
            }
        }
    }; */
}
